## kvday2 - HW3 - NER

To run the code, simply execute the jupyter in order in `./kas_source/main_train_test.ipynb`. That will (1) convert the data to a spacy-compatible foramt, (2) train a custom Distill-BERT model for NER, and (3) convert the results back to the original format, and (4) submit the results for scoring against the official scorer. 

The scorrer must be run with python 3.9, as far as I can tell. The other code is not very sensitive to python versions or other complex dependencies.

#### Dependencies

```bash
# no strict version dependencies.
pip install tqdm spacy csv pandas numpy torch transformers
```

## Official scoring results

My official scoring results are stored in `./scorer/kvday2_FINAL_eval_scores`.
